<?php
// ******-******-*****-
//  Main php 
//  For more information you can mail the develeper
// Dev-eMail : xxxxx@mail.dz
// ******-******-*****-

// Load php Addional Function (Custom Function)
require "src/function.php";

// Load the HTML template file
$templateFile = "src/main.html";

// Replace placeholders in the template with dynamic content
$templateContent = file_get_contents($templateFile);

if (isset($_GET['action'])) {
    if ($_GET['action'] == 'search') {
        $searchContent = searchDatabase("", "", "", "p");
        $templateContent = str_replace("{searchContent}", $searchContent, $templateContent);

    } else {
        $templateContent = str_replace("{searchContent}", '', $templateContent);
    }
} else {
    // Not yet Devloped 
    $templateContent = str_replace("{searchContent}", '', $templateContent);
}
// Echo the modified HTML
echo $templateContent;
?>