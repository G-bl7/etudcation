CREATE DATABASE voyage;

CREATE TABLE continent (
    idcon integer,
    nomcon VARCHAR(20),
    PRIMARY KEY(idcon)
);

CREATE TABLE pays (
    idpay integer,
    nompay VARCHAR(20),
    idcon integer,
    PRIMARY KEY(idpay),
    foreign key (idcon) references continent(idcon)
);

CREATE TABLE ville (
    idvil integer,
    nomvil VARCHAR(20),
    descvil VARCHAR(255),
    idpay integer,
    PRIMARY KEY(idvil),
    foreign key (idpay) references pays (idpay)
);

CREATE TABLE site (
    idsit integer,
    nomsit VARCHAR(30),
    cheminphoto VARCHAR(255),
    idvil integer,
    PRIMARY KEY(idsit),
    foreign key (idvil) references ville (idvil)
);

CREATE TABLE necessaire (
    idnec integer,
    typenec VARCHAR(10),
    nomnec VARCHAR(20),
    idvil integer,
    PRIMARY KEY(idnec),
    foreign key (idvil) references ville (idvil)
);

SELECT
    * INTO OUTFILE '/tmp/continent.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n'
FROM
    continent;

SELECT
    * INTO OUTFILE '/tmp/pays.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n'
FROM
    pays;

SELECT
    * INTO OUTFILE '/tmp/ville.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n'
FROM
    ville;

SELECT
    * INTO OUTFILE '/tmp/site.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n'
FROM
    site;

SELECT
    * INTO OUTFILE '/tmp/necessaire.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n'
FROM
    necessaire;