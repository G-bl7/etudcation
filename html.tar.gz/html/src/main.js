
    function handleClickSearch() {
      window.location.href = "/index.php?action=search";

    }