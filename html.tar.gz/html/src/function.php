<?php
function searchDatabase($paysName, $siteName, $continentName, $villeName)
{
    if (empty($paysName) && empty($siteName) && empty($continentName) && empty($villeName)) {
        return []; // Return an empty result
    }
    // Database configuration
    $servername = "localhost";
    $username = "xx";
    $password = "xxxx";
    $dbname = "voyage";

    // Create a database connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Build the SQL query based input provided
    $query = "SELECT ville.idvil, ville.nomvil
              FROM ville
              JOIN pays ON ville.idpay = pays.idpay
              JOIN continent ON pays.idcon = continent.idcon
              JOIN site ON ville.idvil = site.idvil
              WHERE 1=1";

    // Fech the condition and add when it's needed!
    if (!empty($paysName)) {
        $query .= " AND pays.nompay LIKE '" . $paysName . "%'";
    }

    if (!empty($siteName)) {
        $query .= " AND site.nomsit LIKE '".siteName."%'";
    }

    if (!empty($continentName)) {
        $query .= " AND continent.nomcon LIKE '".continentName."%'";
    }

    if (!empty($villeName)) {
        $query .= " AND ville.nomvil LIKE '" . $villeName . "%'";
    }
    $result = mysqli_query($conn, "SELECT * FROM pays");
    $return_rechercher = "";
    if ($result) {
        // Fetch the query result
        while ($row = mysqli_fetch_assoc($result)) {
            // Process the data as needed
            $return_rechercher = $return_rechercher. " <a href='xxxxxxxx' > <li val='" . $row['idpay'] . "'>" . $row['nompay'] . "</li> </a>";
        }
    
        // free the memory used by mysqli
        mysqli_free_result($result);
    } else {
        // error
        echo "Error executing query: " . mysqli_error($conn);
    }
    return  $return_rechercher;
}
?>